from django.db import models

class Registration(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    mobile = models.CharField(max_length=15)
    roll_number = models.CharField(max_length=20)
    college = models.CharField(max_length=200)
    event1 = models.CharField(max_length=50)
    event2 = models.CharField(max_length=50, blank=True, null=True)
    transaction_id = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return f"{self.name} - {self.event1}"
