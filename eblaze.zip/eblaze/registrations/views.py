from django.shortcuts import render, redirect
from .models import Registration
from django.http import HttpResponse
def index(request):
    return render(request, 'index.html')

from django.http import HttpResponse

def register(request):
    if request.method == "POST":
        print("POST request received!")  # Check if this appears in the terminal

        name = request.POST.get('name')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        roll_number = request.POST.get('roll')
        college = request.POST.get('college')
        event1 = request.POST.get('event_number_1')
        event2 = request.POST.get('event_number_2', '')
        transaction_id = request.POST.get('transaction_id')

        print(f"Received Data: {name}, {email}, {mobile}, {roll_number}, {college}, {event1}, {event2}, {transaction_id}")

        if not (name and email and mobile and roll_number and college and event1 and transaction_id):
            return HttpResponse("Error: Missing required fields!", status=400)

        try:
            Registration.objects.create(
                name=name,
                email=email,
                mobile=mobile,
                roll_number=roll_number,
                college=college,
                event1=event1,
                event2=event2,
                transaction_id=transaction_id
            )
            print("Data saved successfully!")
            return redirect('success')
        except Exception as e:
            print(f"Error: {e}")
            return HttpResponse(f"Database Error: {e}", status=500)

    return render(request, 'register.html')

def success(request):
    return render(request, 'success.html')
